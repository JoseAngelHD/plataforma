<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
$containerNav = $containerNav ?? 'container-fluid';
$navbarDetached = ($navbarDetached ?? '');
?>

<!-- Navbar -->
<?php if(isset($navbarDetached) && $navbarDetached == 'navbar-detached'): ?>
<nav class="layout-navbar <?php echo e($containerNav); ?> navbar navbar-expand-xl <?php echo e($navbarDetached); ?> align-items-center bg-navbar-theme" id="layout-navbar">
<?php endif; ?>
<?php if(isset($navbarDetached) && $navbarDetached == ''): ?>
<nav class="layout-navbar navbar navbar-expand-xl align-items-center bg-navbar-theme" id="layout-navbar">
  <div class="<?php echo e($containerNav); ?>">
    <?php endif; ?>

      <!-- Menu toggle for mobile view -->
      <div class="layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0">
        <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
          <i class="bx bx-menu bx-md"></i>
        </a>
      </div>
      <!-- Brand logo -->
      <div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
        <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
          <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
          <span class="app-brand-text demo menu-text fw-bold text-heading"><?php echo e(config('variables.templateName')); ?></span>
        </a>
      </div>

      <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        <!-- User profile -->
        <ul class="navbar-nav flex-row align-items-center ms-auto">
          <!-- User -->
          <li class="nav-item navbar-dropdown dropdown-user dropdown">
            <a class="nav-link dropdown-toggle hide-arrow p-0" href="javascript:void(0);" data-bs-toggle="dropdown">
              <div class="avatar avatar-online">
                <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt class="w-px-40 h-auto rounded-circle">
              </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <a class="dropdown-item" href="javascript:void(0);">
                  <div class="d-flex">
                    <div class="flex-grow-1">
                      <h6 class="mb-0">
                        <?php if(Auth::check()): ?>
                          <?php echo e(Auth::user()->name); ?>

                        <?php else: ?>
                          Guest
                        <?php endif; ?>
                      </h6>
                      <small class="text-muted">
                        <?php if(Auth::check()): ?>
                          <?php echo e(Auth::user()->role); ?> <!-- Aquí se muestra el rol del usuario -->
                        <?php else: ?>
                          Sin rol
                        <?php endif; ?>
                      </small>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <div class="dropdown-divider my-1"></div>
              </li>
              <li>
                <form method="POST" action="<?php echo e(route('logout')); ?>" id="logout-form">
                  <?php echo csrf_field(); ?>
                  <a class="dropdown-item" href="javascript:void(0);" onclick="document.getElementById('logout-form').submit();">
                    <i class="bx bx-power-off bx-md me-3"></i><span>Salir de RECOFI</span>
                  </a>
                </form>
              </li>
            </ul>
          </li>
          <!--/ User -->
        </ul>
      </div>

      <?php if(!isset($navbarDetached)): ?>
    </div>
    <?php endif; ?>
  </nav>
  <!-- / Navbar -->

<?php /**PATH D:\OneDrive\plataforma\resources\views/layouts/sections/navbar/navbar.blade.php ENDPATH**/ ?>