

<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">Gestión de Usuarios</h5>
                <!-- Botón para abrir el modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createUserModal">
                    Agregar Nuevo Usuario
                </button>
            </div>
            <div class="card-body">
                <?php if($users->isEmpty()): ?>
                    <p>No hay usuarios registrados.</p>
                <?php else: ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->roles->pluck('name')->first() ?? 'Sin rol asignado'); ?></td>
                                    <td>
                                        <!-- Botón para editar usuario -->
                                        <button type="button" class="btn btn-sm btn-warning btn-edit" data-id="<?php echo e($user->id); ?>" data-bs-toggle="modal" data-bs-target="#editUserModal">Editar</button>

                                        <!-- Formulario para eliminar usuario -->
                                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display:inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de eliminar este usuario?')">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal para crear un nuevo usuario -->
<div class="modal fade" id="createUserModal" tabindex="-1" aria-labelledby="createUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createUserModalLabel">Crear Nuevo Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Formulario para crear usuario -->
                <form id="createUserForm" action="<?php echo e(route('users.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Nombre</label>
                        <input type="text" name="name" class="form-control" id="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña</label>
                        <input type="password" name="password" class="form-control" id="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">Confirmar Contraseña</label>
                        <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Rol</label>
                        <select name="role" id="role" class="form-control" required>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Crear Usuario</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal para editar usuario -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Editar Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Formulario para editar usuario -->
                <form id="editUserForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> <!-- Usamos PUT para la actualización -->

                    <div class="mb-3">
                        <label for="edit-name" class="form-label">Nombre</label>
                        <input type="text" name="name" class="form-control" id="edit-name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit-email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="edit-email" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit-password" class="form-label">Contraseña (Opcional)</label>
                        <input type="password" name="password" class="form-control" id="edit-password">
                    </div>
                    <div class="mb-3">
                        <label for="edit-role" class="form-label">Rol</label>
                        <select name="role" id="edit-role" class="form-control" required>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Scripts para manejar el formulario de forma dinámica -->
<script>
// Función para crear usuario mediante AJAX
document.getElementById('createUserForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevenir la recarga de la página

    let form = this;
    let formData = new FormData(form);

    // Enviar el formulario vía AJAX
    fetch(form.action, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Ocultar el modal
            $('#createUserModal').modal('hide');
            
            // Mostrar mensaje de éxito
            Swal.fire({
                icon: 'success',
                title: data.message, // Mensaje de éxito
                showConfirmButton: false,
                timer: 1500
            });

            // Agregar nueva fila a la tabla
            let newRow = `
                <tr>
                    <td>${data.user.name}</td>
                    <td>${data.user.email}</td>
                    <td>${data.role}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-warning btn-edit" data-id="${data.user.id}" data-bs-toggle="modal" data-bs-target="#editUserModal">Editar</button>
                        <button type="button" class="btn btn-sm btn-danger btn-delete" data-id="${data.user.id}">Eliminar</button>
                    </td>
                </tr>
            `;
            document.querySelector('table tbody').innerHTML += newRow;

            // Recargar los eventos de eliminar y editar
            reloadEvents();
        } else {
            // Mostrar mensaje de error
            Swal.fire({
                icon: 'error',
                title: 'Error al crear el usuario',
                text: data.message || 'Ocurrió un error al intentar crear el usuario.',
            });
        }
    })
    .catch(error => console.log('Error:', error));
});

// Cargar datos en el modal de edición
document.querySelectorAll('.btn-edit').forEach(button => {
    button.addEventListener('click', function () {
        const userId = this.dataset.id;

        fetch(`/users/${userId}/edit`)
            .then(response => response.json())
            .then(data => {
                if (data) {
                    // Llenar los campos del modal
                    document.getElementById('edit-name').value = data.name;
                    document.getElementById('edit-email').value = data.email;
                    document.getElementById('edit-role').value = data.role;

                    // Actualizar la acción del formulario
                    document.getElementById('editUserForm').action = `/users/${userId}`;
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error al cargar los datos del usuario',
                    });
                }
            })
            .catch(error => {
                console.log('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error al cargar los datos del usuario',
                });
            });
    });
});

// Actualizar usuario mediante AJAX con SweetAlert
document.getElementById('editUserForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevenir la recarga de la página

    let form = this;
    let formData = new FormData(form);

    fetch(form.action, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Ocultar el modal
            $('#editUserModal').modal('hide');
            
            // Mostrar mensaje de éxito
            Swal.fire({
                icon: 'success',
                title: data.message, // Mensaje de éxito
                showConfirmButton: false,
                timer: 1500
            });

            // Actualizar la fila en la tabla
            let row = document.querySelector(`button[data-id='${data.user.id}']`).closest('tr');
            row.innerHTML = `
                <td>${data.user.name}</td>
                <td>${data.user.email}</td>
                <td>${data.role}</td>
                <td>
                    <button type="button" class="btn btn-sm btn-warning btn-edit" data-id="${data.user.id}" data-bs-toggle="modal" data-bs-target="#editUserModal">Editar</button>
                    <button type="button" class="btn btn-sm btn-danger btn-delete" data-id="${data.user.id}">Eliminar</button>
                </td>
            `;

            // Recargar los eventos de eliminar y editar
            reloadEvents();
        } else {
            // Mostrar mensaje de error
            Swal.fire({
                icon: 'error',
                title: 'Error al actualizar el usuario',
                text: data.message || 'Ocurrió un error al intentar actualizar el usuario.',
            });
        }
    })
    .catch(error => console.log('Error:', error));
});

// Eliminar usuario mediante AJAX con SweetAlert
function reloadEvents() {
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault(); // Prevenir la recarga de la página

            const userId = this.dataset.id;

            Swal.fire({
                title: '¿Estás seguro de eliminar este usuario?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, eliminarlo',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`/users/${userId}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: data.message, // Mensaje de éxito
                                showConfirmButton: false,
                                timer: 1500
                            });

                            // Eliminar la fila de la tabla
                            document.querySelector(`button[data-id='${userId}']`).closest('tr').remove();
                        } else {
                            // Mostrar mensaje de error
                            Swal.fire({
                                icon: 'error',
                                title: 'Error al eliminar el usuario',
                                text: data.message || 'Ocurrió un error al intentar eliminar el usuario.',
                            });
                        }
                    })
                    .catch(error => console.log('Error:', error));
                }
            });
        });
    });
}

// Inicializar los eventos al cargar la página
reloadEvents();

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OneDrive\plataforma\resources\views/users/index.blade.php ENDPATH**/ ?>