

<?php $__env->startSection('title', 'Colegios / RECOFI'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xxl-8 mb-4 order-0">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title text-primary mb-3">Listado de Colegios</h5>
        <a href="<?php echo e(route('schools.create')); ?>" class="btn btn-primary mb-4">Crear Colegio</a>
        
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Dirección</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OneDrive\plataforma\resources\views/schools/index.blade.php ENDPATH**/ ?>